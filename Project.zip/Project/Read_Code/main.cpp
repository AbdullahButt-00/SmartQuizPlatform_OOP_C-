#include<conio.h>
#include <iostream>
#include <fstream>
#include <string>
#include"Class.h"
#include"Functions.cpp"
#include <string.h>
#include <cstring>
#include <sstream>
#include <cctype>
#include <ctime>
using namespace std;




void instructions();
void st_menu(Student& student,Quiz (&quiz)[9],QBank (&q)[9]);
void t_menu(Teacher& teacher,QBank (&q)[9]);
int countWords(string s);
bool isSubstring(const string& str, const string& substr);

string R;
string iD, Password, Name, topic;
static int q_no,marks,t,date,t_marks;
static int l=0,add_marks=0;

static int obj=0;
double* m_report = new double[5];
int* p = new int[3]{0, 0, 0};
string* n = new string[5]{"\0"};


double Guess;
double Total;



class user;
class Student;
class Time;
class Teacher;
class QBank;
class Quiz;
class Attendance;
class Analytics;





int main() 
{
QBank q_Bank[9];
Quiz qz[9]; 
Attendance at[5];
Analytics  result;

Student s[5];
Teacher t;
string a;
int select,an;




do {
       cout<<endl;
cout<<"                                     |-------------------------------------------|"<<endl;
cout<<"                                     | WELCOME TO THE EXAMINATION SYSTEM         |"<<endl;
cout<<"                                     |           USER:                           |"<<endl;
cout<<"                                     |  PRESS 1 : Teacher Menue                  |"<<endl;
cout<<"                                     |  PRESS 2 : Student Menue                  |"<<endl;
cout<<"                                     |  PRESS 3 : Check Attendance & Report      |"<<endl;
cout<<"                                     |  PRESS 4 : Check Analytics                |"<<endl;
cout<<"                                     |_ PRESS any Number : Instructions         _|"<<endl;
       
        cout << "Enter your choice: ";
        getline(cin,a);
while( !(a=="1" || a=="2" || a=="3" || a=="4" || a=="5" || a=="6" || a=="7"|| a=="8"|| a=="9"|| a=="10") )
{   
try{an = stoi(a);
}catch( invalid_argument& e) 
{
cout<<  "Invalid INPUT!"<<endl;
cout<<"  Please Enter a valid Integer (1,2,3,4,5,....)" << endl;
getline(cin,a);
}
}

select=stoi(a);

        switch (select) 
        {
            case 1:
                t_menu(t,q_Bank);
                break;
            case 2:
                st_menu(s[obj],qz,q_Bank);
                break;
            case 3: 
cout<<"                        -------------------------------------------"<<endl;
cout<<"                        ATTENDANCE SHEET AND RESULT                "<<endl;
cout<<"                        Students which attempted the Quiz so far   "<<endl;
cout<<"                        Along with their Marks                     "<<endl;
cout<<"                        -------------------------------------------"<<endl;
                    for(int i=0;i<5;i++)  {  at[i].set_att( n[i] ) ; at[i].set_st_marks( m_report[i] ) ; }
                    for(int i=0;i<5;i++)  {  at[i].display_att() ; }   
                    break;
            case 4: 
cout<<"                       | -------------- |"<<endl;
cout<<"                       | QUIZ ANALYTICS |"<<endl;
cout<<"                       | -------------- |"<<endl;
                    cout<<endl<<"SUMMARY OF TOTAL CORRECT ATTEMPTED QUESIONS ACCORDING TO THEIR TYPE IS:"<<endl; 
                    result.set_a(p[0]);result.set_b(p[1]);result.set_c(p[2]);
                    result.display_analytics();
                    cout<<endl;
                    
                    cout<<"Q type"<<endl<<endl;
                    
                    cout<<"Descriptive "<<"|";for(int i=0;i<result.get_a();i++) {cout<<"*"<<" ";} cout<<endl;
                    cout<<"True-False  "<<"|";for(int i=0;i<result.get_b();i++) {cout<<"*"<<" ";} cout<<endl;
                    cout<<"MCQs        "<<"|";for(int i=0;i<result.get_c();i++) {cout<<"*"<<" ";} cout<<endl;
                    cout<<"            ------------------------"<<endl;
                    
                    break;   
            default:
                instructions();
                break;
        }
cout<<endl<<endl;        
cout<<"                        ------------------------------------------------------"<<endl;
cout<<"                        Press any number to go back or Press 0 to terminate   "<<endl;
cout<<"                        ------------------------------------------------------"<<endl;
cin >> a;

    } while (a!="0");


delete[] p;
delete[] m_report;
delete[] n;
return 0;
}







