#ifndef Class
#define Class

#include <iostream>
#include"main.cpp"
#include"Functions.cpp"
#include<conio.h>
#include <fstream>
#include <string>
#include <string.h>
#include <cstring>
#include <sstream>
#include <cctype>
#include <ctime>

using namespace std;

///////////////////////////////////// TIME///////////////////////////////////////////////////////////////////////////////////////

class Time
 {
private:
    int minutes;
public:
  void set_time(int a) { minutes=a;}
  
  int get_time() { return minutes;}
  
 };    


////////////////////////////////////// QBANK///////////////////////////////////////////////////////////////////////////////////////
class QBank
 {
private:
    string Q;
    string *OPTION;



public:
    QBank() {
        
        OPTION = new string[3];
           Q="\0";
        
    }

    ~QBank() {
      
        delete[] OPTION;
    }
    
    void set_Q(string s) {
        Q= s;
    }
    
    string get_Q() const {
        return Q;
    }

    

    
    void set_OPTION(int i, const string& value) 
    {
        OPTION[i] = value;
    }
    
    string get_OPTION(int i) const 
    {
        return OPTION[i];
    }

    
    
    

void display_QBank()
{


cout<<">"<<Q<<endl;
for(int i=0; i<3;i++) {
            cout << OPTION[i] << endl;
        }
        cout << endl;
}


};


////////////////////////////////////// QUIZ///////////////////////////////////////////////////////////////////////////////////////




class Quiz 
 {
private:
    
string q;
string* op;


public:
    Quiz() {
        op = new string[3];
        q=" ";

        }

    ~Quiz() {
        
        delete[] op;
    }
    
    void set_q(string s) {
        q= s;
    }
    
    string get_q() const {
        return q;
    }

    

    
    void set_op(int i, const string& value) 
    {
        op[i] = value;
    }
    
    string get_op(int i) const 
    {
        return op[i];
    }

    
 void attemp_quiz()
{ 
   string  answer; int correct_answer; int ans;
   
   cout<<"> "<<q<<endl;
   for(int i=0; i<3;i++)
   {
        
   cout << op[i] << endl;
   
   
   }
   cout<<"|----------------|"<<endl;
   cout<<" Enter ur Answer:"<<endl;
   cout<<"|----------------|"<<endl<<endl;
   getline(cin,answer);
   
   if(op[0]=="") 
   { 
        cout <<"No.Of Words in Your Answer is: "<<countWords(answer)<< endl;
        Total +=  countWords(answer)*0.01;
        cout << "Score = " << Total<<" out of "<<t_marks<<endl;
        cout << endl;
         p[0]+=1;
   }
   
   
  
   else 
   {
   if(op[2]=="")
   {
   
while( !(answer=="1" || answer=="2") )
{   
try{ans = stoi(answer);
}catch( invalid_argument& e) 
{
cout << "Invalid INPUT!"<<endl;
cout<<"  Please Enter a valid Integer (1,2)" << endl;

getline(cin,answer);
}
} 

   
    if  ( isSubstring(op[1],"dabfac4" )   )  { correct_answer=2; }
    else {  correct_answer=1; }
   
   
if ( stoi(answer) == correct_answer) 
    {
        cout << endl;
        cout << "Correct !" << endl;
     
        Total = Total + marks;
        cout << "Score = " << Total<<" out of "<<t_marks<<endl<<endl;
         p[1]+=1;
             
    }
    else 
    {
        cout << endl;
        cout << "Wrong !" << endl;
        cout << "Correct answer = "
             << correct_answer
             << "." << endl;
             Total = Total + 0;
        cout << endl;
    }
    
    
    }
    
    
  
    else
   {
  
   
		while( !(answer=="1" || answer=="2" || answer=="3") )
		{   
		try{ans = stoi(answer);
		}catch( invalid_argument& e) 
		{
		cout << "Invalid INPUT!"<<endl;
		cout<<"  Please Enter a valid Integer (1,2,3)" << endl;

		getline(cin,answer);
		}
		} 
   
   
    if  ( isSubstring(op[0],"dabfac4" )   )  { correct_answer=1; }
    else if  ( isSubstring(op[1],"dabfac4" )   )  { correct_answer=2; }
    else {  correct_answer=3; }
   
 //cout<<"MCQ--"<<endl;

    if ( stoi(answer) == correct_answer) 
          {
		cout << endl;
		cout << "Correct !" << endl;
		Total = Total + marks;
		cout << "Score = " << Total<<" out of "<<t_marks<<endl<<endl;
		p[2]+=1;
             
          }
    
    
    else 
              {
		cout << endl;
		cout << "Wrong !" << endl;
		cout << "Correct answer = "
		     << correct_answer
		     << "." << endl;
		Total = Total + 0;
		cout << endl;
              }
    
    
   }
    
    }


      
} 
};





//////////////////////////////////////      USER     ///////////////////////////////////////////////////////////////////////////////////////




class user 
{  
private:

string name;
string ID;
string password;

public:

user() 
{ 
  name= '\0';
  ID= '\0';
  password= '\0';
  
};

user(string name, string ID, string password)
{ 
        this->name= name;
        this->ID = ID;
        this->password=password;
}
    
    void set_name(string a)
    { name=a; }
    
    string get_name()
    { return name; }
    
    void set_ID(string b)
    { ID=b; }
    
    string get_ID()
    { return ID; }
    
    void set_password(string c)
    { password=c; }
    
    string get_password()
    { return password; }
    
    
bool checkPass ( string p) const  
{
 
bool upper= false, lower= false, digit= false, special = false;
   
if (p.length() < 6)  {return false;}
   
for (int i = 0; i < p.length(); i++) 
 {
  char c = p[i];
  if (c >= 'A' && c <= 'Z')
   { upper = true; }
  else if (c >= 'a' && c <= 'z') 
  { lower = true; }
  else if (c >= '0' && c <= '9') 
  { digit = true; }
  else { special= true; }
    
 }
return upper && lower && digit && special;
}


string* Course( string s, string file)  ////////////
{

string* c= new string[11];
ifstream inputFile(file);

 inputFile.is_open();
 string line;
 int x=0;
 string cell1;string cell2; string cell3;
 while (getline(inputFile, line) && x<1000) 
{
stringstream lineStream(line);// copy 1 line to string stream
 
int y=0; 
getline(lineStream, cell1 , ',');
getline(lineStream, cell1 , ',');
getline(lineStream, cell2 , ',');
        
int k=0;
if(cell1==s)
{        
while (getline(lineStream, cell3 , ','))   
  {

c[k]=cell3; 
k++;
	     
  } 
}       	
   x++;
    
}

    
inputFile.close();

return c;

}



string Registered(string n) const
{   
ifstream inputFile("t.csv");
	string arry[11];
	arry[0]="Programming Fundamentals";
	arry[1]="Object Oriented Programming";
	arry[2]="Introduction To Computing";
	arry[3]="Data Structures";
	arry[4]="Analysis of Algorithms";
	arry[5]="Software Requirements Engineering";
	arry[6]="Research Methodology";
	arry[7]="Big Data Analytics";
	arry[8]="Artificial Intelligence";
	arry[9]="Deep Learning";
	arry[10]="Digital Image Processing";
	
	string c;
    if (!inputFile.is_open()) 
    {
        cout << "Failed to open file!" << endl;
        return " ";
    }
    string line;
    const int ROWS = 1; 
    int row = 0;
    int x=0;
    string cell;
    
    while (getline(inputFile, line)) {
      
        stringstream lineStream(line);// copy 1 line to string stream
        
        int y=0;
        while (getline(lineStream, cell, ',')) 
		{
        	if(cell==n)
        	{
        	while (getline(lineStream, cell, ','))
        	    {
        		if(cell=="1")
        		c=arry[y];
        		y++;
        	    }
        	
        	}
        	
        }
        x++;
    }
    inputFile.close();

  
   return c;
}


bool Exist_ID( string ID) const  
{
 
 bool flag=0;


 if( isSubstring(ID, "i-00") )
{

 ifstream inputFile("t.csv");
  if (inputFile.is_open()) 
		{
		    string line;
		    
		    int x=0;
		    string cell;
		    while (getline(inputFile, line)) 
		{
		       stringstream lineStream(line);
		       int y=0;
		       while (getline(lineStream, cell, ',') && y<2) 
				{
				if(cell==ID) { flag=1;}
				y++;
				}
			x++;
		}
		   
		    inputFile.close();

		}

}



 
 else
  {
 
   ifstream inputFile("example.csv");
	  if (inputFile.is_open()) 
	{
	    string line;
	    
	    int x=0;
	    string cell;
	    while (getline(inputFile, line)) 
	    {
	       stringstream lineStream(line);
	       int y=0;
	       while (getline(lineStream, cell, ',') && y<2) 
			{
			if(cell==ID) { flag=1;}
			y++;
		        }
		x++;
	    }
	   
	    inputFile.close();
	}
  }

return flag;
}


string Exist_name(string ID) const
{
 
 string n;
 if( isSubstring(ID, "i-00") )
 {
	 ifstream inputFile("t.csv");
	  if (inputFile.is_open()) 
	{
	    string line;
	    
	    int x=0;
	    string cell;
	  while (getline(inputFile, line)) 
	{
	       stringstream lineStream(line);
	       int y=0;
	       while (getline(lineStream, cell, ',') && y<2) 
			{
			if(cell==ID) 
			{
			 getline(lineStream, cell, ',');
			 n=cell;
			 }
			y++;
		        }
		x++;
	}
	   
	    inputFile.close();

	} 
}
 else
{ 
	  ifstream inputFile("example.csv");
	  if (inputFile.is_open()) 
	{
	    string line;
	    
	    int x=0;
	    string cell;
	    while (getline(inputFile, line)) 
	{
	       stringstream lineStream(line);
	       int y=0;
	       while (getline(lineStream, cell, ',') && y<2) 
			{
			if(cell==ID) 
			{
			 getline(lineStream, cell, ',');
			  n=cell;
			 }
			y++;
		        }
		x++;
	}
	   
	    inputFile.close();

	}
}

 return n; 
 }
 
 
 
  
};


/////////////////////////////// TEACHER //////////////////////////////////////////////////////////////////////////

class Teacher : public user
{  
public:
string NU_ID;
string name;
string *course;
string password;
Time tim;

public:
    Teacher() 
    {
        NU_ID = '\0';
        password= '\0';
        name= '\0';
        course = new string[11];
        for (int i = 0; i < 11; i++)
         {  course[i] = "\0";  }
    }

 Teacher(string roll_no, string name, string* course, string password) 
 {
        NU_ID = roll_no;
        this->name=name;
        this->password=password;
        this->course = new string[11];
        for (int i = 0; i < 11; i++) 
        {
            this->course[i] = course[i];
        }
 }
 
 ~Teacher() 
 {  delete[] course; cout << "Teacher object with NU_ID " << NU_ID << " has been destroyed." << endl; }

  
 void setNU_ID(string roll) 
 { NU_ID= roll; }

 void setName(string name) 
 { this->name= name; }
 
 void setTime(int t)  { tim.set_time(t); }
 int getTime()  { return tim.get_time(); }

 void setCourse(string* course) 
 {
    for (int i = 0; i < 11; i++) 
    { this->course[i] = course[i]; }
 }


 string getNU_ID() const 
 { return NU_ID; }

 string getName() const 
 { return name; }

 string* getCourse() const 
 { return course; }
 
   void set_t_password(string c)
    { password=c; }
    
   string get_t_password()
    { return password; }
 
 void display_t() const
 { 
 cout<<"NU-ID: "<<NU_ID<<endl;
 cout<<"Teacher Name: "<<name<<endl;
 cout<<"TEacher Registered Courses: "<<endl;
  for (int i = 0; i < 11; i++)
         {  cout<<course[i]<<" "; }
         
 }
 


void generateQuiz( string file,QBank (&q)[9] )
{


ifstream inputFile(file);

        
        if (!inputFile.is_open()) 
        {
            cout << "Failed to open file." << endl;
        
        }      

        
        string line;
        int x=0, i=0;
        while (getline(inputFile, line)) 
        {
        
        
            
            
             if(line=="88f7ace" ) 
            {   
                getline(inputFile, line);
                q[x].set_Q(line);
                x++;
            }
            
            
            if(line=="b94d27b" ) 
            {  
            getline(inputFile, line);
                q[x].set_Q(line);
                
            for(int j=0; j<2;j++)
               { getline(inputFile, line);
                q[x].set_OPTION(j,line);}
                
                x++;
            }
            
            if(line=="2efcde9") { 
            getline(inputFile, line);
                q[x].set_Q(line);
                
              for(int j=0; j<3;j++) 
               { getline(inputFile, line);
               q[x].set_OPTION(j,line);
               }
                i++;
                x++;
                }            
            
            
         
        
        }
   
     
    cout<<" -------------------Quiz set-------------------"<<endl;   

}



 
 
};

///////////////////////////////      Attendence          ////////////////////////////////////////////////////////////////////////////

class Attendance
{
private: 

string att; 
double st_marks;


public:
void set_att( string n)    {  att=n;}

string get_att() const     { return att; }

void set_st_marks( double n)    {  st_marks=n;}

double  get_st_marks() const     { return st_marks; }

void display_att()          { cout<<att<<" "<<st_marks<<" / "<<t_marks<<endl;  }


};








///////////////////////////////      Analytics         /////////////////////////////////////////////////////////

class Analytics

{
private: int a,b,c;

public:
void set_a( int n)    {  a=n;}
void set_b( int n)    {  b=n;}
void set_c( int n)    {  c=n;}

int get_a() const     { return a; }
int get_b() const     { return b; }
int get_c() const     { return c; }


void display_analytics()    
{ 
cout<<"Descriptive Quesions "<< a <<endl;  
cout<<"true-false Quesions "<< b <<endl;
cout<<"MCQ Quesions "<< c <<endl;
  
}


};


///////////////////////////////      STUDENT           /////////////////////////////////////////////////////////

class Student : public user
{  
private:
string Rollno;
string nam;
string *course;
string password;

public:
    Student() 
    {
        Rollno = '\0';
        nam= '\0';
        course = new string[11];
        for (int i = 0; i < 11; i++)
         {  course[i] = "\0"; }
    }

 Student(string roll_no, string nam, int* course, string password) 
 {
        Rollno = roll_no;
        this->password=password;
        this->nam=nam;
        this->course = new string[11];
        for (int i = 0; i < 11; i++) 
        {
            this->course[i] = course[i];
        }
 }
 
  ~Student() 
 {  delete[] course; cout << "Student object with Roll No " << Rollno << " has been destroyed." << endl; }

  
 void setRollno(string roll_no) 
 { Rollno = roll_no; }

 void setName(string nam) 
 { this->nam= nam; }

 void setCourse(string* course) 
 {
    for (int i = 0; i < 11; i++) 
    { this->course[i] = course[i]; }
 }
 
void set_course(int i,string s) 
             { course[i]=s; }

 
 void set_st_password(string c)
    { password=c; }

 string getRollno() const 
 { return Rollno; }

 string getName() const 
 { return nam; }

 string getCourse(int i) const 
 { return course[i]; }

 string get_st_password()
    { return password; }
 
 
 void display_st() const
 { 
 cout<<"Roll.No: "<<Rollno<<endl;
 cout<<"Student Name: "<<nam<<endl;
 cout<<"Student Registered Courses: "<<endl;
  for (int i = 0; i < 11; i++)
         {  cout<<course[i]<<" "; }
         
 }
 


void GiveQuiz(Quiz (&quiz)[9], QBank (&q)[9])
{


Total=0;

    const int SIZE = 9; 
    int arr[SIZE]; 
    int randNum; 
    int index; 
    bool used[SIZE] = {false}; 
    srand(time(nullptr)); 
    
    for (int i = 0; i < SIZE; i++) 
    {
        do {
            randNum = rand() % SIZE; 
        } while (used[randNum]); 

        arr[i] = randNum; 
        used[randNum] = true; 
    }
    


	int a;

	cout<<"|------------------------------------|"<<endl;
	cout<<"|-------------Quiz-------------------|"<<endl;
	cout<<"|------------------------------------|"<<endl<<endl;
	   
	   for(int i=0; i<q_no ; i++)
	    {
	    a=arr[i];
	    quiz[a].set_q( q[a].get_Q() );
	    quiz[a].set_op( 0, q[a].get_OPTION(0) );
	    quiz[a].set_op( 1, q[a].get_OPTION(1) );
	    quiz[a].set_op( 2, q[a].get_OPTION(2) );
	    quiz[a].attemp_quiz();
	    }
    
    
m_report[add_marks]=Total;
add_marks++;   
}




};



#endif 
