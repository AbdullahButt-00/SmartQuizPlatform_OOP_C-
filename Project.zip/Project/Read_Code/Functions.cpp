#include<conio.h>
#include"main.cpp"
#include"Class.h"
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <cstring>
#include <sstream>
#include <cctype>
#include <ctime>
using namespace std;


int countWords(string s)
{

istringstream iss(s);
    string word;
    int count = 0;
    
    while (iss >> word) {
        count++;
    }
return count;
}

bool isSubstring(const string& str, const string& substr) 
{
   
    if (str.find(substr) != string::npos) 
    {
        return true; 
    }
    else {
        return false;
    }
}




void st_menu(Student& student,Quiz (&quiz)[9],QBank (&q)[9])
{

string i;
cout<<"Use your NU ID as your login ID: Use your NU ID as your login ID."<<endl<<"This is a unique identifier assigned to you by the system that ensures your identity."<<endl<<"Enter Your NU ID like : (22I-xxxx) "<<endl;
//cin.ignore(); 
getline(cin,i); student.setRollno(i);
cout<<endl;

while( student.Exist_ID(i)!= true )
{
        cout<<"THIS STUDENT  ID DOES NOT EXIST"<<endl;
        cout<<"KINDLY RE-ENTER NU-ID"<<endl;
        getline(cin,i);   
        student.Exist_ID(i);
   
       
}

student.setRollno(i); 
cout<<"| ------------------------------- |"<<endl;
cout<<"| This student Exists :)          |"<<endl;
cout<<"| ------------------------------- |"<<endl; 


Name=student.Exist_name(i);
student.setName(Name);
cout<<"Name:"<<student.getName()<<endl;
cout<<endl;



cout<<">> Set up a strong password: Choose a strong password that is at least six characters long and includes a mix of upper and lowercase letters, numbers, and special characters. Avoid using easily guessable passwords like your name or birthdate."<<endl;
cout<<">> Keep your password private: Do not share your password with anyone else. If you suspect that someone else knows your password, change it immediately."<<endl;
cout<<">> Use the appropriate menu to change password: If you need to change your password, use the appropriate menu provided in the application. Follow the instructions carefully to ensure that your new password meets the requirements."<<endl;
cout<<">> Keep your password confidential: When entering your password, the system will display asterisks (*). Ensure that nobody is watching you while you enter your password."<<endl;
cout<<">> Enter Password : like (2Aa!01)"<<endl;
char c;
do 
{
 c = getch();
cout << '*';
Password += c;
} while (c != '\r' && c!=13 && c!='\n');
Password.erase(Password.size() - 1);

student.set_st_password(Password);
cout<<endl; 

while(student.checkPass( Password )!= true)
{
cout<<"KINDLY READ THE INSTRUCTIONS CAREFULLY AND RE-ENTER YOUR PASSWORD"<<endl;
getline(cin,Password);
student.checkPass( Password );
} 

cout<<"Password has been set :) "<<endl;  
student.set_st_password(Password);
cout<<endl;
obj++; 


student.setCourse( student.Course(i, "example.csv") );

        
string arry[11];
arry[0]="Programming Fundamentals";
arry[1]="Object Oriented Programming";
arry[2]="Introduction To Computing";
arry[3]="Data Structures";
arry[4]="Analysis of Algorithms";
arry[5]="Software Requirements Engineering";
arry[6]="Research Methodology";
arry[7]="Big Data Analytics";
arry[8]="Artificial Intelligence";
arry[9]="Deep Learning";
arry[10]="Digital Image Processing";

for (int i = 0; i < 11; i++) {  if (student.getCourse(i)!="0")           student.set_course( i,arry[i]);       }  

cout<<"Registered Courses For < "<<student.getName()<<" > are :"<<endl;
for (int i = 0; i < 11; i++)
{
if (student.getCourse(i)!="0")  cout<<student.getCourse(i)<<" "<<endl;
}

cout<<endl<<endl;
student.display_st();
cout<<endl<<endl<<endl;



string choice;
cout<<endl<<"KIndly Enter Course name of which u want to give Quiz "<<endl;
for (int i = 0; i < 11; i++)
{
if (student.getCourse(i)!="0")  cout<<student.getCourse(i)<<" "<<endl;
}
cout<<endl<<endl;
getline(cin,choice); int it=0; bool f=0; 

cout<<"//////////////////////////////////////////////////////////////////////////////"<<endl;
cout<<" Course :"<<R<<endl;
cout<<" Topic  :"<<topic<<endl;
cout<<" Quiz is being Conducted on "<<date<<" of this month"<<endl;
cout<<" Dear Student u hv "<<" "<<t<<" "<<" minutes for ur Quiz"<<endl;
cout<<" Each Question carries "<<marks<<" Marks"<<endl;
cout<<" U have to "<<q_no<<" Questions"<<endl;
cout<<"//////////////////////////////////////////////////////////////////////////////"<<endl<<endl;


for (int i = 0; i < 11; i++)
{
if (student.getCourse(i)==R && student.getCourse(i)==choice )  {f=1; n[l]=Name; student.GiveQuiz(quiz,q); break;   }
} 
if(f==0) 
{ 
cout<<"   Sorry, Possible Errors "<<endl;
cout<<"   Invalid input "<<endl;
cout<<"   You Are Not Registered in this course"<<endl; 
cout<<"   Quiz missing-- :( "<<endl;
} 

l++;
}









void t_menu( Teacher& teacher,QBank (&q)[9] )
{

cout<<"Hello Teacher....."<<endl;
string iD;

cout<<"Use your NU ID as your login ID: "<<endl<<"This is a unique identifier assigned to you by the system that ensures your identity."<<endl<<"Enter Your NU ID like : (i-xxxx) "<<endl;
//cin.ignore();
getline(cin,iD); teacher.setNU_ID(iD);
cout<<endl;

while(teacher.Exist_ID(iD)!= true)
{
        cout<<"TEACHER ID NOT MATCHED"<<endl;
        cout<<"KINDLY RE-ENTER NU-ID"<<endl;
        getline(cin,iD);   
        teacher.Exist_ID(iD);
   
       
}
 
cout<<"| ------------------------------- |"<<endl;
cout<<"|      Teacher Exists :)          |"<<endl;
cout<<"| ------------------------------- |"<<endl; 

teacher.setNU_ID(iD); 

Name=teacher.Exist_name(iD);
teacher.setName(Name);






cout<<">> Set up a strong password: Choose a strong password that is at least six characters long and includes a mix of upper and lowercase letters, numbers, and special characters. Avoid using easily guessable passwords like your name or birthdate."<<endl;
cout<<">> Keep your password private: Do not share your password with anyone else. If you suspect that someone else knows your password, change it immediately."<<endl;
cout<<">> Use the appropriate menu to change password: If you need to change your password, use the appropriate menu provided in the application. Follow the instructions carefully to ensure that your new password meets the requirements."<<endl;
cout<<">> Keep your password confidential: When entering your password, the system will display asterisks (*). Ensure that nobody is watching you while you enter your password."<<endl;
cout<<">> Enter Password : like (2Aa!01)"<<endl<<endl;
char c;
do 
{
c = getch();
cout << '*';
Password += c;
} while (c != '\r' && c!=13 && c!='\n');
Password.erase(Password.size() - 1);

teacher.set_t_password(Password);
cout<<endl;
 
while(teacher.checkPass( Password )!= true )
{
cout<<"KINDLY READ THE INSTRUCTIONS CAREFULLY AND RE-ENTER YOUR PASSWORD"<<endl;
getline(cin,Password);
teacher.checkPass( Password );
} 



cout<<"Password has been set :) "<<endl;  
teacher.set_t_password(Password);
cout<<endl; 
cout<<"Welcome : "<<teacher.getName()<<endl; 
cout<<"You are Resgistered for "<<teacher.Registered(Name)<<" course"<<endl;    R=teacher.Registered(Name); 

cout<<endl;
teacher.setCourse( teacher.Course(iD, "t.csv") );
teacher.display_t();
cout<<endl;
cout<<"Kindly set Topic for the quiz"<<endl;
getline(cin,topic);
cout<<"Kindly Number of Qustions to be added"<<endl;
cin>>q_no;
while( q_no>8 )
{
cout<<"  Sorry for the InConvenience :("<<endl;
cout<<"  Quiz-Bank has only 8 total Questions"<<endl;
cout<<"  Kindly Enter no.of Questions accordingly"<<endl;
cin>>q_no;
}

cout<<endl;

cout<<"  Kindly set Marks for each Question"<<endl;
cin>>marks;
cout<<"  Kindly set Duration of Quiz"<<endl;
cout<<"  Set time in minutes"<<endl;
cin>>t;  teacher.setTime(t);
cout<<"  Kindly set Date for qUIZ"<<endl;
cout<<"  Set Date in days"<<endl;
cin>>date;

t_marks=marks*q_no;

if(iD=="i-0001") { teacher.generateQuiz("bda.txt",q ); }
else if(iD=="i-0002") { teacher.generateQuiz("pf.txt",q ); }
else if(iD=="i-0003") { teacher.generateQuiz("ds.txt",q); }
else if(iD=="i-0004") { teacher.generateQuiz("dip.txt",q ); }
else if(iD=="i-0005") { teacher.generateQuiz("se.txt",q ); }
else if(iD=="i-0006") { teacher.generateQuiz("algos.txt",q ); }
else if(iD=="i-0007") { teacher.generateQuiz("ic.txt",q ); }
else if(iD=="i-0008") { teacher.generateQuiz("dl.txt",q ); }
else if(iD=="i-0009") { teacher.generateQuiz("ai.txt",q ); }
else if(iD=="i-0010") { teacher.generateQuiz("oop.txt",q ); }
else if(iD=="i-0011") { teacher.generateQuiz("rm.txt",q ); }
else cout<<"Quiz Can not be generated"<<endl<<"FIN !"<<endl;


}



void instructions()
{

cout<<"||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"<<endl;
cout<<endl<<endl;
cout<<"                                     |-------------------------------------|"<<endl;
cout<<"                                     |  EXAMINATION SYSTEM                 |"<<endl;
cout<<"                                     |  THIS SYSYTEM SUPPORRTS             |"<<endl;
cout<<"                                     |_  TEACHER & STRUDENT               _|"<<endl;

cout<<endl;
cout<<"  ***********************"<<endl;
cout<<"  * For Teacher User:   *"<<endl;
cout<<"  ***********************"<<endl<<endl;

cout<<"> First, create a question bank: As a teacher, create a question bank with a variety of questions, including multiple-choice questions, true/false questions, short answer questions, etc."<<endl;
cout<<"> Create a Quiz/Assignment: Create a quiz or assignment from the question bank you created. Set the date and time for the quiz to be available to students."<<endl;
cout<<"> Share Quiz/Assignment with students: Share the quiz/assignment link or access code with students so they can access it on the scheduled date and time."<<endl;
cout<<"> Monitor student progress: Monitor student progress during the quiz/assignment. You can see how many questions have been answered, which questions have been answered correctly or incorrectly, and how much time is remaining."<<endl;
cout<<"> Analyze Quiz/Assignment: After the quiz/assignment is completed, the software will automatically mark the quiz and generate a marks report. Use this report to evaluate student performance and provide feedback."<<endl;
cout<<"> Analyze Analytics report: The system will also generate an analytics report that shows useful insights about the evaluation. This report can help you identify areas where students may be struggling or where additional instruction is needed."<<endl;
cout<<"> Save Quiz/Assignment and Reports: The system will store all the data permanently on disk using file reading/writing."<<endl<<endl;

cout<<"  ***********************"<<endl;
cout<<"  * For Student User:   *"<<endl;
cout<<"  ***********************"<<endl<<endl;


cout<<"> Access Quiz/Assignment: Log in to the application and access the quiz/assignment  shared by the teacher."<<endl;
cout<<"> Complete Quiz/Assignment: Complete the quiz/assignment within the specified time frame. Answer all the questions to the best of your knowledge."<<endl;
cout<<"> Submit Quiz/Assignment: Submit the quiz/assignment before the deadline."<<endl;
cout<<"> Time management: Make sure you manage your time effectively during the exam. Allocate enough time for each section and ensure that you have enough time to review your answers before submitting them"<<endl;
cout<<"> Check the exam instructions: Carefully read the exam instructions provided by your instructor. Make sure you understand the format, time limit, and how to submit your exam."<<endl;
cout<<"> Don't cheat: Cheating is not acceptable in any examination, including online exams. Make sure you complete the exam on your own, without the help of others or any unauthorized resources."<<endl;
cout<<"> View Marks Report: After submitting the quiz/assignment, the system will automatically mark the quiz and generate a marks report. View the report to see your performance."<<endl;
cout<<"> View Analytics report: The system will also generate an analytics report that shows useful insights about the evaluation. You can view this report to identify areas where you may need additional instruction or to see how you performed compared to your peers."<<endl<<endl;

cout<<"||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"<<endl;



}




