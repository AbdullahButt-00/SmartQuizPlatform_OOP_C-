#include<conio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <cstring>
#include <sstream>
#include <cctype>
#include <ctime>
using namespace std;

string R;
string iD, Password, Name, topic;
static int q_no,marks,t,date,t_marks;
static int l=0,add_marks=0;

static int obj=0;
double* m_report = new double[5];
int* p = new int[3]{0, 0, 0};
string* n = new string[5]{"\0"};


double Guess;
double Total;


class Time;
class user;
class Student;
class Teacher;
class QBank;
class Quiz;
class Attendance;
class Analytics;


void instructions();
void st_menu(Student& student,Quiz (&quiz)[9],QBank (&q)[9]);
void t_menu(Teacher& teacher,QBank (&q)[9]);
int countWords(string s);
bool isSubstring(const string& str, const string& substr) ;

int countWords(string s)
{

istringstream iss(s);
    string word;
    int count = 0;
    
    while (iss >> word) {
        count++;
    }
return count;
}

bool isSubstring(const string& str, const string& substr) 
{
   
    if (str.find(substr) != string::npos) 
    {
        return true; 
    }
    else {
        return false;
    }
}



class Time
 {
private:
    int minutes;
public:
  void set_time(int a) { minutes=a;}
  
  int get_time() { return minutes;}
  
   ~Time()
{ 
cout<<"Time Destructor"<<endl;
} 
  
 };    


////////////////////////////////////// QBANK///////////////////////////////////////////////////////////////////////////////////////
class QBank
 {
private:
    string Q;
    string *OPTION;



public:
    QBank() {
        
        OPTION = new string[3];
           Q="\0";
        
    }

    ~QBank() {
      
        delete[] OPTION;
    }
    
    void set_Q(string s) {
        Q= s;
    }
    
    string get_Q() const {
        return Q;
    }

    

    
    void set_OPTION(int i, const string& value) 
    {
        OPTION[i] = value;
    }
    
    string get_OPTION(int i) const 
    {
        return OPTION[i];
    }

    
    
    

void display_QBank()
{


cout<<">"<<Q<<endl;
for(int i=0; i<3;i++) {
            cout << OPTION[i] << endl;
        }
        cout << endl;
}


};


////////////////////////////////////// QUIZ///////////////////////////////////////////////////////////////////////////////////////




class Quiz 
 {
private:
    
string q;
string* op;


public:
    Quiz() {
        op = new string[3];
        q=" ";

        }

    ~Quiz() {
        
        delete[] op;
    }
    
    void set_q(string s) {
        q= s;
    }
    
    string get_q() const {
        return q;
    }

    

    
    void set_op(int i, const string& value) 
    {
        op[i] = value;
    }
    
    string get_op(int i) const 
    {
        return op[i];
    }

    
 void attemp_quiz()
{ 
   string  answer; int correct_answer; int ans;
   
   cout<<"> "<<q<<endl;
   for(int i=0; i<3;i++)
   {
        
   cout << op[i] << endl;
   
   
   }
   cout<<"|----------------|"<<endl;
   cout<<" Enter ur Answer:"<<endl;
   cout<<"|----------------|"<<endl<<endl;
   getline(cin,answer);
   
   if(op[0]=="") 
   { 
        cout <<"No.Of Words in Your Answer is: "<<countWords(answer)<< endl;
        Total +=  countWords(answer)*0.01;
        cout << "Score = " << Total<<" out of "<<t_marks<<endl;
        cout << endl;
         p[0]+=1;
   }
   
   
  
   else 
   {
   if(op[2]=="")
   {
   
while( !(answer=="1" || answer=="2") )
{   
try{ans = stoi(answer);
}catch( invalid_argument& e) 
{
cout << "Invalid INPUT!"<<endl;
cout<<"  Please Enter a valid Integer (1,2)" << endl;

getline(cin,answer);
}
} 

   
    if  ( isSubstring(op[1],"dabfac4" )   )  { correct_answer=2; }
    else {  correct_answer=1; }
   
   
if ( stoi(answer) == correct_answer) 
    {
        cout << endl;
        cout << "Correct !" << endl;
     
        Total = Total + marks;
        cout << "Score = " << Total<<" out of "<<t_marks<<endl<<endl;
         p[1]+=1;
             
    }
    else 
    {
        cout << endl;
        cout << "Wrong !" << endl;
        cout << "Correct answer = "
             << correct_answer
             << "." << endl;
             Total = Total + 0;
        cout << endl;
    }
    
    
    }
    
    
  
    else
   {
  
   
		while( !(answer=="1" || answer=="2" || answer=="3") )
		{   
		try{ans = stoi(answer);
		}catch( invalid_argument& e) 
		{
		cout << "Invalid INPUT!"<<endl;
		cout<<"  Please Enter a valid Integer (1,2,3)" << endl;

		getline(cin,answer);
		}
		} 
   
   
    if  ( isSubstring(op[0],"dabfac4" )   )  { correct_answer=1; }
    else if  ( isSubstring(op[1],"dabfac4" )   )  { correct_answer=2; }
    else {  correct_answer=3; }
   
 //cout<<"MCQ--"<<endl;

    if ( stoi(answer) == correct_answer) 
          {
		cout << endl;
		cout << "Correct !" << endl;
		Total = Total + marks;
		cout << "Score = " << Total<<" out of "<<t_marks<<endl<<endl;
		p[2]+=1;
             
          }
    
    
    else 
              {
		cout << endl;
		cout << "Wrong !" << endl;
		cout << "Correct answer = "
		     << correct_answer
		     << "." << endl;
		Total = Total + 0;
		cout << endl;
              }
    
    
   }
    
    }


      
} 
};





//////////////////////////////////////      USER     ///////////////////////////////////////////////////////////////////////////////////////




class user 
{  
private:

string name;
string ID;
string password;

public:

user() 
{ 
  name= '\0';
  ID= '\0';
  password= '\0';
  
};

user(string name, string ID, string password)
{ 
        this->name= name;
        this->ID = ID;
        this->password=password;
}
    
    void set_name(string a)  ///////////>>>>>>>>>>>>>>>>>>>>>>
    { name=a; }
    
    string get_name()
    { return name; }
    
    void set_ID(string b)
    { ID=b; }
    
    string get_ID()
    { return ID; }
    
  virtual   void set_password(string c)=0;
    
   virtual  string get_password()=0;
    
    
    
bool checkPass ( string p) const  
{
 
bool upper= false, lower= false, digit= false, special = false;
   
if (p.length() < 6)  {return false;}
   
for (int i = 0; i < p.length(); i++) 
 {
  char c = p[i];
  if (c >= 'A' && c <= 'Z')
   { upper = true; }
  else if (c >= 'a' && c <= 'z') 
  { lower = true; }
  else if (c >= '0' && c <= '9') 
  { digit = true; }
  else { special= true; }
    
 }
return upper && lower && digit && special;
}


string* Course( string s, string file)  ////////////
{

string* c= new string[11];
ifstream inputFile(file);

 inputFile.is_open();
 string line;
 int x=0;
 string cell1;string cell2; string cell3;
 while (getline(inputFile, line) && x<1000) 
{
stringstream lineStream(line);// copy 1 line to string stream
 
int y=0; 
getline(lineStream, cell1 , ',');
getline(lineStream, cell1 , ',');
getline(lineStream, cell2 , ',');
        
int k=0;
if(cell1==s)
{        
while (getline(lineStream, cell3 , ','))   
  {

c[k]=cell3; 
k++;
	     
  } 
}       	
   x++;
    
}

    
inputFile.close();

return c;

}



string Registered(string n) const
{   
ifstream inputFile("t.csv");
	string arry[11];
	arry[0]="Programming Fundamentals";
	arry[1]="Object Oriented Programming";
	arry[2]="Introduction To Computing";
	arry[3]="Data Structures";
	arry[4]="Analysis of Algorithms";
	arry[5]="Software Requirements Engineering";
	arry[6]="Research Methodology";
	arry[7]="Big Data Analytics";
	arry[8]="Artificial Intelligence";
	arry[9]="Deep Learning";
	arry[10]="Digital Image Processing";
	
	string c;
    if (!inputFile.is_open()) 
    {
        cout << "Failed to open file!" << endl;
        return " ";
    }
    string line;
    const int ROWS = 1; // Maximum number of rows 
    int row = 0;
    int x=0;
    string cell;
    
    while (getline(inputFile, line)) {
      
        stringstream lineStream(line);// copy 1 line to string stream
        
        int y=0;
        while (getline(lineStream, cell, ',')) 
		{
        	if(cell==n)
        	{
        	while (getline(lineStream, cell, ','))
        	    {
        		if(cell=="1")
        		c=arry[y];
        		y++;
        	    }
        	
        	}
        	
        }
        x++;
    }
    inputFile.close();

  
   return c;
}


bool Exist_ID( string ID) const  
{
 
 bool flag=0;


 if( isSubstring(ID, "i-00") )
{

 ifstream inputFile("t.csv");
  if (inputFile.is_open()) 
		{
		    string line;
		    
		    int x=0;
		    string cell;
		    while (getline(inputFile, line)) 
		{
		       stringstream lineStream(line);
		       int y=0;
		       while (getline(lineStream, cell, ',') && y<2) 
				{
				if(cell==ID) { flag=1;}
				y++;
				}
			x++;
		}
		   
		    inputFile.close();

		}

}



 
 else
  {
 
   ifstream inputFile("example.csv");
	  if (inputFile.is_open()) 
	{
	    string line;
	    
	    int x=0;
	    string cell;
	    while (getline(inputFile, line)) 
	    {
	       stringstream lineStream(line);
	       int y=0;
	       while (getline(lineStream, cell, ',') && y<2) 
			{
			if(cell==ID) { flag=1;}
			y++;
		        }
		x++;
	    }
	   
	    inputFile.close();
	}
  }

return flag;
}


string Exist_name(string ID) const
{
 
 string n;
 if( isSubstring(ID, "i-00") )
 {
	 ifstream inputFile("t.csv");
	  if (inputFile.is_open()) 
	{
	    string line;
	    
	    int x=0;
	    string cell;
	  while (getline(inputFile, line)) 
	{
	       stringstream lineStream(line);
	       int y=0;
	       while (getline(lineStream, cell, ',') && y<2) 
			{
			if(cell==ID) 
			{
			 getline(lineStream, cell, ',');
			 n=cell;
			 }
			y++;
		        }
		x++;
	}
	   
	    inputFile.close();

	} 
}
 else
{ 
	  ifstream inputFile("example.csv");
	  if (inputFile.is_open()) 
	{
	    string line;
	    
	    int x=0;
	    string cell;
	    while (getline(inputFile, line)) 
	{
	       stringstream lineStream(line);
	       int y=0;
	       while (getline(lineStream, cell, ',') && y<2) 
			{
			if(cell==ID) 
			{
			 getline(lineStream, cell, ',');
			  n=cell;
			 }
			y++;
		        }
		x++;
	}
	   
	    inputFile.close();

	}
}

 return n; 
 }
 
 virtual ~user() 
{ 
cout<<"User Destructor"<<endl;
} 
 
  
};


/////////////////////////////// TEACHER /////////////////////////////////////////////////////////

class Teacher : public user
{  
public:
string NU_ID;
string name;
string *course;
string password;
Time tim;

public:
    Teacher() 
    {
        NU_ID = '\0';
        password= '\0';
        name= '\0';
        course = new string[11];
        for (int i = 0; i < 11; i++)
         {  course[i] = "\0";  }
    }

 Teacher(string roll_no, string name, string* course, string password) 
 {
        NU_ID = roll_no;
        this->name=name;
        this->password=password;
        this->course = new string[11];
        for (int i = 0; i < 11; i++) 
        {
            this->course[i] = course[i];
        }
 }
 
 virtual ~Teacher() 
 {  delete[] course; cout << "Teacher object with NU_ID " << NU_ID << " has been destroyed." << endl; }

  
 void setNU_ID(string roll) 
 { NU_ID= roll; }

 void setName(string name) 
 { this->name= name; }
 
 void setTime(int t)  { tim.set_time(t); }
 int getTime()  { return tim.get_time(); }

 void setCourse(string* course) 
 {
    for (int i = 0; i < 11; i++) 
    { this->course[i] = course[i]; }
 }


 string getNU_ID() const 
 { return NU_ID; }

 string getName() const 
 { return name; }

 string* getCourse() const 
 { return course; }
 
  // void set_t_password(string c)
    //{ password=c; }
    
   //string get_t_password()
    //{ return password; }
 
 
   virtual   void set_password(string c)
    { password=c; }
    
   virtual  string get_password()
    { return password; }
    
 void display_t() const
 { 
 cout<<"NU-ID: "<<NU_ID<<endl;
 cout<<"Teacher Name: "<<name<<endl;
 cout<<"TEacher Registered Courses: "<<endl;
  for (int i = 0; i < 11; i++)
         {  cout<<course[i]<<" "; }
         
 }
 


void generateQuiz( string file,QBank (&q)[9] )
{


ifstream inputFile(file);

        
        if (!inputFile.is_open()) 
        {
            cout << "Failed to open file." << endl;
        
        }      

        
        string line;
        int x=0, i=0;
        while (getline(inputFile, line)) 
        {
        
        
            
            
             if(line=="88f7ace" ) 
            {   
                getline(inputFile, line);
                q[x].set_Q(line);
                x++;
            }
            
            
            if(line=="b94d27b" ) 
            {  
            getline(inputFile, line);
                q[x].set_Q(line);
                
            for(int j=0; j<2;j++)
               { getline(inputFile, line);
                q[x].set_OPTION(j,line);}
                
                x++;
            }
            
            if(line=="2efcde9") { 
            getline(inputFile, line);
                q[x].set_Q(line);
                
              for(int j=0; j<3;j++) 
               { getline(inputFile, line);
               q[x].set_OPTION(j,line);
               }
                i++;
                x++;
                }            
            
            
         
        
        }
   
     
    cout<<" -------------------Quiz set-------------------"<<endl;   

}



 
 
};

///////////////////////////////      Attendence          /////////////////////////////////////////////////////////

class Attendance
{
private: 

string att; 
double st_marks;


public:
void set_att( string n)    {  att=n;}

string get_att() const     { return att; }

void set_st_marks( double n)    {  st_marks=n;}

double  get_st_marks() const     { return st_marks; }

void display_att()          { cout<<att<<" "<<st_marks<<" / "<<t_marks<<endl;  }

 ~Attendance()
{ 
cout<<"Attendance Destructor"<<endl;
}

};








///////////////////////////////      Analytics         /////////////////////////////////////////////////////////

class Analytics

{
private: int a,b,c;

public:
void set_a( int n)    {  a=n;}
void set_b( int n)    {  b=n;}
void set_c( int n)    {  c=n;}

int get_a() const     { return a; }
int get_b() const     { return b; }
int get_c() const     { return c; }


void display_analytics()    
{ 
cout<<"Descriptive Quesions "<< a <<endl;  
cout<<"true-false Quesions "<< b <<endl;
cout<<"MCQ Quesions "<< c <<endl;
  
}

~Analytics()
{ 
cout<<"Analytics Destructor"<<endl;
}
};


///////////////////////////////      STUDENT           /////////////////////////////////////////////////////////

class Student : public user
{  
private:
string Rollno;
string nam;
string *course;
string password;

public:
    Student() 
    {
        Rollno = '\0';
        nam= '\0';
        course = new string[11];
        for (int i = 0; i < 11; i++)
         {  course[i] = "\0"; }
    }

 Student(string roll_no, string nam, int* course, string password) 
 {
        Rollno = roll_no;
        this->password=password;
        this->nam=nam;
        this->course = new string[11];
        for (int i = 0; i < 11; i++) 
        {
            this->course[i] = course[i];
        }
 }
 
  virtual ~Student() 
 {  delete[] course; cout << "Student object with Roll No " << Rollno << " has been destroyed." << endl; }

  
 void setRollno(string roll_no) 
 { Rollno = roll_no; }

 void setName(string nam) 
 { this->nam= nam; }

 void setCourse(string* course) 
 {
    for (int i = 0; i < 11; i++) 
    { this->course[i] = course[i]; }
 }
 
void set_course(int i,string s) 
             { course[i]=s; }

 
 //void set_st_password(string c)
   // { password=c; }

 string getRollno() const 
 { return Rollno; }

 string getName() const 
 { return nam; }

 string getCourse(int i) const 
 { return course[i]; }

// string get_st_password()
  //  { return password; }
 
 virtual   void set_password(string c)
    { password=c; }
    
   virtual  string get_password()
    { return password; }
    
    
 void display_st() const
 { 
 cout<<"Roll.No: "<<Rollno<<endl;
 cout<<"Student Name: "<<nam<<endl;
 cout<<"Student Registered Courses: "<<endl;
  for (int i = 0; i < 11; i++)
         {  cout<<course[i]<<" "; }
         
 }
 


void GiveQuiz(Quiz (&quiz)[9], QBank (&q)[9])
{


Total=0;

    const int SIZE = 9; 
    int arr[SIZE]; 
    int randNum; 
    int index; 
    bool used[SIZE] = {false}; 
    srand(time(nullptr)); 
    
    for (int i = 0; i < SIZE; i++) 
    {
        do {
            randNum = rand() % SIZE; 
        } while (used[randNum]); 

        arr[i] = randNum; 
        used[randNum] = true; 
    }
    


	int a;

	cout<<"|------------------------------------|"<<endl;
	cout<<"|-------------Quiz-------------------|"<<endl;
	cout<<"|------------------------------------|"<<endl<<endl;
	   
	   for(int i=0; i<q_no ; i++)
	    {
	    
	    cout<<"Q: "<<i+1<<" ";
	    a=arr[i];
	    quiz[a].set_q( q[a].get_Q() );
	    quiz[a].set_op( 0, q[a].get_OPTION(0) );
	    quiz[a].set_op( 1, q[a].get_OPTION(1) );
	    quiz[a].set_op( 2, q[a].get_OPTION(2) );
	    quiz[a].attemp_quiz();
	    }
    
    
m_report[add_marks]=Total;
add_marks++;   
}




};

int main() 
{
QBank q_Bank[9];
Quiz qz[9]; 
Attendance at[5];
Analytics  result;

Student s[5];
Teacher t;
string a;
int select,an;




do {
       cout<<endl;
cout<<"                                     |-------------------------------------------|"<<endl;
cout<<"                                     | WELCOME TO THE EXAMINATION SYSTEM         |"<<endl;
cout<<"                                     |           USER:                           |"<<endl;
cout<<"                                     |  PRESS 1 : Teacher Menue                  |"<<endl;
cout<<"                                     |  PRESS 2 : Student Menue                  |"<<endl;
cout<<"                                     |  PRESS 3 : Check Attendance & Report      |"<<endl;
cout<<"                                     |  PRESS 4 : Check Analytics                |"<<endl;
cout<<"                                     |_ PRESS any Number : Instructions         _|"<<endl;
       
        cout << "Enter your choice: ";
        getline(cin,a);
while( !(a=="1" || a=="2" || a=="3" || a=="4" || a=="5" || a=="6" || a=="7"|| a=="8"|| a=="9"|| a=="10") )
{   
try{an = stoi(a);
}catch( invalid_argument& e) 
{
cout<<  "Invalid INPUT!"<<endl;
cout<<"  Please Enter a valid Integer (1,2,3,4,5,....)" << endl;
getline(cin,a);
}
}

select=stoi(a);

        switch (select) 
        {
            case 1:
                t_menu(t,q_Bank);
                break;
            case 2:
                st_menu(s[obj],qz,q_Bank);
                break;
            case 3: 
cout<<"                        -------------------------------------------"<<endl;
cout<<"                        ATTENDANCE SHEET AND RESULT                "<<endl;
cout<<"                        Students which attempted the Quiz so far   "<<endl;
cout<<"                        Along with their Marks                     "<<endl;
cout<<"                        -------------------------------------------"<<endl;
                    for(int i=0;i<5;i++)  {  at[i].set_att( n[i] ) ; at[i].set_st_marks( m_report[i] ) ; }
                    for(int i=0;i<5;i++)  {  at[i].display_att() ; }   
                    break;
            case 4: 
cout<<"                       | -------------- |"<<endl;
cout<<"                       | QUIZ ANALYTICS |"<<endl;
cout<<"                       | -------------- |"<<endl;
                    cout<<endl<<"SUMMARY OF TOTAL CORRECT ATTEMPTED QUESIONS ACCORDING TO THEIR TYPE IS:"<<endl; 
                    result.set_a(p[0]);result.set_b(p[1]);result.set_c(p[2]);
                    result.display_analytics();
                    cout<<endl;
                    
                    cout<<"Q type"<<endl<<endl;
                    
                    cout<<"Descriptive "<<"|";for(int i=0;i<result.get_a();i++) {cout<<"*"<<" ";} cout<<endl;
                    cout<<"True-False  "<<"|";for(int i=0;i<result.get_b();i++) {cout<<"*"<<" ";} cout<<endl;
                    cout<<"MCQs        "<<"|";for(int i=0;i<result.get_c();i++) {cout<<"*"<<" ";} cout<<endl;
                    cout<<"            ------------------------"<<endl;
                    
                    break;   
            default:
                instructions();
                break;
        }
cout<<endl<<endl;        
cout<<"                        ------------------------------------------------------"<<endl;
cout<<"                        Press any number to go back or Press 0 to terminate   "<<endl;
cout<<"                        ------------------------------------------------------"<<endl;
cin >> a;

    } while (a!="0");


delete[] p;
delete[] m_report;
delete[] n;
return 0;
}







void st_menu(Student& student,Quiz (&quiz)[9],QBank (&q)[9])
{

string i;
cout<<"Use your NU ID as your login ID: Use your NU ID as your login ID."<<endl<<"This is a unique identifier assigned to you by the system that ensures your identity."<<endl<<"Enter Your NU ID like : (22I-xxxx) "<<endl;
//cin.ignore(); 
getline(cin,i); student.setRollno(i);
cout<<endl;

while( student.Exist_ID(i)!= true )
{
        cout<<"THIS STUDENT  ID DOES NOT EXIST"<<endl;
        cout<<"KINDLY RE-ENTER NU-ID"<<endl;
        getline(cin,i);   
        student.Exist_ID(i);
   
       
}

student.setRollno(i); 
cout<<"| ------------------------------- |"<<endl;
cout<<"| This student Exists :)          |"<<endl;
cout<<"| ------------------------------- |"<<endl; 


Name=student.Exist_name(i);
student.setName(Name);
cout<<"Name:"<<student.getName()<<endl;
cout<<endl;



cout<<">> Set up a strong password: Choose a strong password that is at least six characters long and includes a mix of upper and lowercase letters, numbers, and special characters. Avoid using easily guessable passwords like your name or birthdate."<<endl;
cout<<">> Keep your password private: Do not share your password with anyone else. If you suspect that someone else knows your password, change it immediately."<<endl;
cout<<">> Use the appropriate menu to change password: If you need to change your password, use the appropriate menu provided in the application. Follow the instructions carefully to ensure that your new password meets the requirements."<<endl;
cout<<">> Keep your password confidential: When entering your password, the system will display asterisks (*). Ensure that nobody is watching you while you enter your password."<<endl;
cout<<">> Enter Password : like (2Aa!01)"<<endl;
char c;
do 
{
 c = getch();
cout << '*';
Password += c;
} while (c != '\r' && c!=13 && c!='\n');
Password.erase(Password.size() - 1);

student.set_password(Password);
cout<<endl; 

while(student.checkPass( Password )!= true)
{
cout<<"KINDLY READ THE INSTRUCTIONS CAREFULLY AND RE-ENTER YOUR PASSWORD"<<endl;
getline(cin,Password);
student.checkPass( Password );
} 

cout<<"Password has been set :) "<<endl;  
student.set_password(Password);
cout<<endl;
obj++; 


student.setCourse( student.Course(i, "example.csv") );

        
string arry[11];
arry[0]="Programming Fundamentals";
arry[1]="Object Oriented Programming";
arry[2]="Introduction To Computing";
arry[3]="Data Structures";
arry[4]="Analysis of Algorithms";
arry[5]="Software Requirements Engineering";
arry[6]="Research Methodology";
arry[7]="Big Data Analytics";
arry[8]="Artificial Intelligence";
arry[9]="Deep Learning";
arry[10]="Digital Image Processing";

for (int i = 0; i < 11; i++) {  if (student.getCourse(i)!="0")           student.set_course( i,arry[i]);       }  

cout<<"Registered Courses For < "<<student.getName()<<" > are :"<<endl;
for (int i = 0; i < 11; i++)
{
if (student.getCourse(i)!="0")  cout<<student.getCourse(i)<<" "<<endl;
}

cout<<endl<<endl;
student.display_st();
cout<<endl<<endl<<endl;



string choice;
cout<<endl<<"KIndly Enter Course name of which u want to give Quiz "<<endl;
for (int i = 0; i < 11; i++)
{
if (student.getCourse(i)!="0")  cout<<student.getCourse(i)<<" "<<endl;
}
cout<<endl<<endl;
getline(cin,choice); int it=0; bool f=0; 

cout<<"//////////////////////////////////////////////////////////////////////////////"<<endl;
cout<<" Course :"<<R<<endl;
cout<<" Topic  :"<<topic<<endl;
cout<<" Quiz is being Conducted on "<<date<<" of this month"<<endl;
cout<<" Dear Student u hv "<<" "<<t<<" "<<" minutes for ur Quiz"<<endl;
cout<<" Each Question carries "<<marks<<" Marks"<<endl;
cout<<" U have to "<<q_no<<" Questions"<<endl;
cout<<"//////////////////////////////////////////////////////////////////////////////"<<endl<<endl;


for (int i = 0; i < 11; i++)
{
if (student.getCourse(i)==R && student.getCourse(i)==choice )  {f=1; n[l]=Name; student.GiveQuiz(quiz,q); break;   }
} 
if(f==0) 
{ 
cout<<"   Sorry, Possible Errors "<<endl;
cout<<"   Invalid input "<<endl;
cout<<"   You Are Not Registered in this course"<<endl; 
cout<<"   Quiz missing-- :( "<<endl;
} 

l++;
}









void t_menu( Teacher& teacher,QBank (&q)[9] )
{

cout<<"Hello Teacher....."<<endl;
string iD;

cout<<"Use your NU ID as your login ID: "<<endl<<"This is a unique identifier assigned to you by the system that ensures your identity."<<endl<<"Enter Your NU ID like : (i-xxxx) "<<endl;
//cin.ignore();
getline(cin,iD); teacher.setNU_ID(iD);
cout<<endl;

while(teacher.Exist_ID(iD)!= true)
{
        cout<<"TEACHER ID NOT MATCHED"<<endl;
        cout<<"KINDLY RE-ENTER NU-ID"<<endl;
        getline(cin,iD);   
        teacher.Exist_ID(iD);
   
       
}
 
cout<<"| ------------------------------- |"<<endl;
cout<<"|      Teacher Exists :)          |"<<endl;
cout<<"| ------------------------------- |"<<endl; 

teacher.setNU_ID(iD); 

Name=teacher.Exist_name(iD);
teacher.setName(Name);






cout<<">> Set up a strong password: Choose a strong password that is at least six characters long and includes a mix of upper and lowercase letters, numbers, and special characters. Avoid using easily guessable passwords like your name or birthdate."<<endl;
cout<<">> Keep your password private: Do not share your password with anyone else. If you suspect that someone else knows your password, change it immediately."<<endl;
cout<<">> Use the appropriate menu to change password: If you need to change your password, use the appropriate menu provided in the application. Follow the instructions carefully to ensure that your new password meets the requirements."<<endl;
cout<<">> Keep your password confidential: When entering your password, the system will display asterisks (*). Ensure that nobody is watching you while you enter your password."<<endl;
cout<<">> Enter Password : like (2Aa!01)"<<endl<<endl;
char c;
do 
{
c = getch();
cout << '*';
Password += c;
} while (c != '\r' && c!=13 && c!='\n');
Password.erase(Password.size() - 1);

teacher.set_password(Password);
cout<<endl;
 
while(teacher.checkPass( Password )!= true )
{
cout<<"KINDLY READ THE INSTRUCTIONS CAREFULLY AND RE-ENTER YOUR PASSWORD"<<endl;
getline(cin,Password);
teacher.checkPass( Password );
} 



cout<<"Password has been set :) "<<endl;  
teacher.set_password(Password);
cout<<endl; 
cout<<"Welcome : "<<teacher.getName()<<endl; 
cout<<"You are Resgistered for "<<teacher.Registered(Name)<<" course"<<endl;    R=teacher.Registered(Name); 

cout<<endl;
teacher.setCourse( teacher.Course(iD, "t.csv") );
teacher.display_t();
cout<<endl;
cout<<"Kindly set Topic for the quiz"<<endl;
getline(cin,topic);
cout<<"Kindly Number of Qustions to be added"<<endl;
cin>>q_no;
while( q_no>8 )
{
cout<<"  Sorry for the InConvenience :("<<endl;
cout<<"  Quiz-Bank has only 8 total Questions"<<endl;
cout<<"  Kindly Enter no.of Questions accordingly"<<endl;
cin>>q_no;
}

cout<<endl;

cout<<"  Kindly set Marks for each Question"<<endl;
cin>>marks;
cout<<"  Kindly set Duration of Quiz"<<endl;
cout<<"  Set time in minutes"<<endl;
cin>>t;  teacher.setTime(t);
cout<<"  Kindly set Date for qUIZ"<<endl;
cout<<"  Set Date in days"<<endl;
cin>>date;

t_marks=marks*q_no;

if(iD=="i-0001") { teacher.generateQuiz("bda.txt",q ); }
else if(iD=="i-0002") { teacher.generateQuiz("pf.txt",q ); }
else if(iD=="i-0003") { teacher.generateQuiz("ds.txt",q); }
else if(iD=="i-0004") { teacher.generateQuiz("dip.txt",q ); }
else if(iD=="i-0005") { teacher.generateQuiz("se.txt",q ); }
else if(iD=="i-0006") { teacher.generateQuiz("algos.txt",q ); }
else if(iD=="i-0007") { teacher.generateQuiz("ic.txt",q ); }
else if(iD=="i-0008") { teacher.generateQuiz("dl.txt",q ); }
else if(iD=="i-0009") { teacher.generateQuiz("ai.txt",q ); }
else if(iD=="i-0010") { teacher.generateQuiz("oop.txt",q ); }
else if(iD=="i-0011") { teacher.generateQuiz("rm.txt",q ); }
else cout<<"Quiz Can not be generated"<<endl<<"FIN !"<<endl;


}



void instructions()
{

cout<<"||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"<<endl;
cout<<endl<<endl;
cout<<"                                     |-------------------------------------|"<<endl;
cout<<"                                     |  EXAMINATION SYSTEM                 |"<<endl;
cout<<"                                     |  THIS SYSYTEM SUPPORRTS             |"<<endl;
cout<<"                                     |_  TEACHER & STRUDENT               _|"<<endl;

cout<<endl;
cout<<"  ***********************"<<endl;
cout<<"  * For Teacher User:   *"<<endl;
cout<<"  ***********************"<<endl<<endl;

cout<<"> First, create a question bank: As a teacher, create a question bank with a variety of questions, including multiple-choice questions, true/false questions, short answer questions, etc."<<endl;
cout<<"> Create a Quiz/Assignment: Create a quiz or assignment from the question bank you created. Set the date and time for the quiz to be available to students."<<endl;
cout<<"> Share Quiz/Assignment with students: Share the quiz/assignment link or access code with students so they can access it on the scheduled date and time."<<endl;
cout<<"> Monitor student progress: Monitor student progress during the quiz/assignment. You can see how many questions have been answered, which questions have been answered correctly or incorrectly, and how much time is remaining."<<endl;
cout<<"> Analyze Quiz/Assignment: After the quiz/assignment is completed, the software will automatically mark the quiz and generate a marks report. Use this report to evaluate student performance and provide feedback."<<endl;
cout<<"> Analyze Analytics report: The system will also generate an analytics report that shows useful insights about the evaluation. This report can help you identify areas where students may be struggling or where additional instruction is needed."<<endl;
cout<<"> Save Quiz/Assignment and Reports: The system will store all the data permanently on disk using file reading/writing."<<endl<<endl;

cout<<"  ***********************"<<endl;
cout<<"  * For Student User:   *"<<endl;
cout<<"  ***********************"<<endl<<endl;


cout<<"> Access Quiz/Assignment: Log in to the application and access the quiz/assignment  shared by the teacher."<<endl;
cout<<"> Complete Quiz/Assignment: Complete the quiz/assignment within the specified time frame. Answer all the questions to the best of your knowledge."<<endl;
cout<<"> Submit Quiz/Assignment: Submit the quiz/assignment before the deadline."<<endl;
cout<<"> Time management: Make sure you manage your time effectively during the exam. Allocate enough time for each section and ensure that you have enough time to review your answers before submitting them"<<endl;
cout<<"> Check the exam instructions: Carefully read the exam instructions provided by your instructor. Make sure you understand the format, time limit, and how to submit your exam."<<endl;
cout<<"> Don't cheat: Cheating is not acceptable in any examination, including online exams. Make sure you complete the exam on your own, without the help of others or any unauthorized resources."<<endl;
cout<<"> View Marks Report: After submitting the quiz/assignment, the system will automatically mark the quiz and generate a marks report. View the report to see your performance."<<endl;
cout<<"> View Analytics report: The system will also generate an analytics report that shows useful insights about the evaluation. You can view this report to identify areas where you may need additional instruction or to see how you performed compared to your peers."<<endl<<endl;

cout<<"||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"<<endl;



}



